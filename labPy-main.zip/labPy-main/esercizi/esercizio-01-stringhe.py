# si modifichi il codice  affinchè
# data una stringa stampi a video un carattere alla volta.

stringa = "modifica il codice che ti suggerisco"

print("stampo tutta la stringa", stringa)

while i < len(frase):
    # che istruzione manca?
    i = i + 1


# stampa a monitor la lunghezza della stringa STRINGA

print(????)
