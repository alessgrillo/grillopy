##converting temperature from Fahrenheit to Celsius
#user defined Function
def temp(c):
    c=int(input("Enter a temperature in Celcius: "))
    return (c * 9 / 5) + 32


print(temp(c))
