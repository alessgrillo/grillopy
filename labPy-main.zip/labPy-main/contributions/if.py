num1=700
num2=700
if  num2>num1:
    print('correct')
elif num1==num2:
    print('both number are same')
   
else:
     print('invalid expression')
     
       
       
 

