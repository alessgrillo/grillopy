#sum of number from 1 to 100 using for loop
#variables defined: n=100 , sum=0, counter(1,101)
n=100
sum=0
for counter in range(1,n+1):
    sum=sum + counter
print("The sum of 1 till 100 is : ",(sum))
    
