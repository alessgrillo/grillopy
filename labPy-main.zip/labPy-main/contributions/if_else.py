x=120
y=20
if x>y:
  print(x)
else:
  print(y)
  
