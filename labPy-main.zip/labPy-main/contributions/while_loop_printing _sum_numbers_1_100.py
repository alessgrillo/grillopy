#excersice while loop
#printing the sum of 1 till 100
#variables sum=0 , i=1



sum=0
i=1
while i <= 100:
       sum=sum+i
       i=i+1
       
       
    
print("The sum of 1 till 100 is ",(sum))

