#while loop example
#printing of numbers from 0 to 9
number=0
while number<10:
    
     print(number)
     number=number+1
    
