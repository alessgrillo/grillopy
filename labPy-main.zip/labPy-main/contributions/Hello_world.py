Hello='Hello World'
Hello='Hello World!'

print(Hello)
#project 2
#Ask user for name,age,city,what they enjoy
#create output
#print output
name=input('Whats ur name? ')
age=input('how old are you? ')
city=input('In which city are you living? ')
hobby=input('whatis your hobby? ')
store="Your name is {} and your of {} years old living in {} and your hobby is {}"
output=store.format(name,age,city,hobby)
print(output)
