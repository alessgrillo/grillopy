# TEXTTOSPEECH #

## UTILIZZO ##
Lo script in questa pagina permette di salvare un file mp3 con l'audio della voce
elettronica, in relazione al testo inserito nella virabile di tipo stringa.

Non è necessario usare il secondo modulo PLAYSOUND, serve solo come test, perhè il file mp3
lo si può eseguire con qualunque programma.

Entrambi i muduli si installano con pip.

**pip install gTTS**

**pip install playsound**

## NOTA ##
Bisogna stare attenti ai permessi per il salvataggio del file mp3, se non salva alcun file, 
bisngna controllare i permessi, quindi avviare lo script come amministratore del sistema.
