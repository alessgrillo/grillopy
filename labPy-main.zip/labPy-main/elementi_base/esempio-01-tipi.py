#python3
#tipi di variabili

numero = 3
stringa = "casa"
booleano = False
reale = 3.14 #float


print(numero)
print(stringa)
print(booleano)
print(reale)


print("moltiplico il ",numero,"per il ",reale,"ottengo ",numero*reale )