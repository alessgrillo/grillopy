#python3

stringa = "casa"


parolaDue = stringa + " arcobaleno"

print("concateno le parole ",parolaDue)