#python3

nome = input("scrivi il nome.. ")

print("ciao",nome )