# labPy

I file inclusi in questo repository sono relativi al corso di studi del Liceo Scientifico a curvatura coding del G.B.Vico di Napoli, anno scolastico 2020/2021
La documentazione di riferimento non ha alcuna pretesa di essere esaustiva, ma è solo un riferimento per le esercitazione svolte in aula.